package pages;

public class AmazonPage extends BasePage {
    
    public AmazonPage(){
        super(driver);
    }

    private String searchField = "//input[@id='twotabsearchtextbox']";
    private String searchButton = "//input[@id='nav-search-submit-button']";
    private String itemTitle = "//div[@id='titleSection']";
    private String item = "//img[@data-image-index='1']";
    
    /**
     * Navigate to URL.
     */
    public void navigateToAmazon(){
        navigateTo("https://www.amazon.com/");
    }

    /**
     * Enter product to be search in search field
     * @param criteria
     */
    public void enterSearchCriteria (String criteria){
        write(searchField, criteria);
    }

    /**
     * Click on search button
     */
    public void clickSearchButon(){
        clickElement(searchButton);
    }

    /**
     * Click on first result in searched product
     */
    public void selectFirsttem(){
    	clickElement(item);
    }

    /**
     * get title of product
     * @return
     */
    public String getTitle(){
        return textFromElement(itemTitle);
    }


}
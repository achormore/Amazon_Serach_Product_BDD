package runner;


import org.testng.annotations.AfterClass;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
import pages.BasePage;

@CucumberOptions(
        features="src/test/resource/feature",
        glue="steps",
        plugin = { "pretty"},
        tags="@Amazon"
)
public class runner  extends AbstractTestNGCucumberTests{
@AfterClass
public static void cleanDriver(){
BasePage.closeBrowser();
}

}
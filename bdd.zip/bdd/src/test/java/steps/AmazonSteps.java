package steps;

import org.testng.Assert;

import io.cucumber.java.en.*;
import pages.AmazonPage;

public class AmazonSteps {

    AmazonPage amazon = new AmazonPage();
    
    @Given("the user navigate to www.amazon.com")
    public void navigatToAmazonPage(){
        amazon.navigateToAmazon();

    }

    @And("search for {string}")
    public void searchCriteria(String item){
        amazon.enterSearchCriteria(item);
    }

    @And("click on search button")
    public void clickOnSearch(){
        amazon.clickSearchButon();
    }
    
    @When("select item 1")
    public void selectItem() {
    	amazon.selectFirsttem();
    }
    
    @Then("user verify Apple Iphone text")
    public void verifyText() {
    	Assert.assertTrue(amazon.getTitle().contains("Apple iPhone"));
    }
}